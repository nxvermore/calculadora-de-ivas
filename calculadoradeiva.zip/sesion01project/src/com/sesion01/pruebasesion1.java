package com.sesion01;

public class pruebasesion1 {

    public static void main(String[] args) {

        //tipos de datos primitivos

        byte numerobyte = 1;
        short numeroshort = 34;
        int numeroint = 34;
        long numerolong = 9598645;

        //tipos de datos de punto flotante

        float numerofloat = 12.5f; //lleva decimales y se añade la f detrás para aclarar que es un float
        double numerodouble = 356.394d;

        //verdaderos o falsos tipo boolean

        boolean verdadomentira = true;
        char chartext = 1;

        //tipos de datos estructurados

        String nombre = "pepe";

        System.out.println(numerobyte);
        System.out.println(numeroshort);
        System.out.println(numeroint);
        System.out.println(numerolong);
        System.out.println(numerofloat);
        System.out.println(numerodouble);
        System.out.println(verdadomentira);
        System.out.println(chartext);
        System.out.println(nombre);

    }
}
